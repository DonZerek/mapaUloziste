package commandPrikazy;

public interface Argument extends Command {

	public boolean exists(Argument a);
}
